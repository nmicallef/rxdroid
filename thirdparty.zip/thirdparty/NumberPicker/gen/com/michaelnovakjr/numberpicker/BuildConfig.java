/** Automatically generated file. DO NOT MODIFY */
package com.michaelnovakjr.numberpicker;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}